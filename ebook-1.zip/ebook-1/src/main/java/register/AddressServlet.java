package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Database;
import profile.Address;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/address")
public class AddressServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Get the previous session
        HttpSession session = request.getSession();

        // Create Address object and set parameters from request
        Address address = new Address();
        address.setUname(request.getParameter("uname"));
        address.setfName(request.getParameter("fname"));
        address.setMobile(Long.parseLong(request.getParameter("mobile")));
        address.setPincode(Integer.parseInt(request.getParameter("pincode")));
        address.setLandmark(request.getParameter("landmark"));
        address.setArea(request.getParameter("area"));
        address.setCity(request.getParameter("city"));
        address.setMandal(request.getParameter("mandal"));
        address.setDistrict(request.getParameter("district"));
        address.setState(request.getParameter("state"));

        // Set Address object as session attribute (if needed)
        session.setAttribute("address", address);

        // Create Database object
        Database db = new Database("user"); // Replace with your database name

        try {
            db.insert2(address);
        } catch (Exception e) {
            e.printStackTrace();
        }
  session.invalidate();
        
        // Respond
  response.sendRedirect("dashboard");
    }
}
