package register;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/deleteBook")
public class DeleteBookServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String bookId = request.getParameter("bookId");

        if (bookId != null) {
            String url = "jdbc:mysql://localhost:3306/user";
            String username = "root";
            String password = "student";

            Connection con = null;
            PreparedStatement ps = null;

            try {
                // Load JDBC Driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish connection
                con = DriverManager.getConnection(url, username, password);

                // Prepare SQL delete query
                String deleteQuery = "DELETE FROM books WHERE bid = ?";
                ps = con.prepareStatement(deleteQuery);
                ps.setString(1, bookId);

                // Execute delete query
                int result = ps.executeUpdate();
                if (result > 0) {
                    response.sendRedirect("delete.jsp"); // Redirect to the books list page after deletion
                } else {
                    response.getWriter().println("Error deleting the book.");
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (ps != null) ps.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
