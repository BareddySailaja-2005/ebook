package register;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Address;
import profile.Database;
import profile.Productfinal;

@WebServlet("/orders72")
public class RetrieveServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getSession().getAttribute("username");

        if (username != null) {
            try {
                Database db = new Database("user");
                List<Productfinal> ordersList = db.getOrdersByUsername(username);  // Correct method call
                request.setAttribute("ordersList", ordersList);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        request.getRequestDispatcher("/orders.jsp").forward(request, response);
    }
}

