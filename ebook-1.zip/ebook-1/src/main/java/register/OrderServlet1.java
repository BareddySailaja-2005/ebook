package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/orders")
public class OrderServlet1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Retrieve form parameters
        String uname = request.getParameter("uname");
        String bName = request.getParameter("bookName");
        String aName = request.getParameter("authorName");
        String DeliveryDate = request.getParameter("deliveryDate");
        String totalPriceStr = request.getParameter("totalprice").replace("Rs. ", "");
        double Price = Double.parseDouble(totalPriceStr);
        String paymenttype = request.getParameter("paymentMethod");


        // Database connection parameters
        String jdbcURL = "jdbc:mysql://localhost:3306/user";
        String dbUser = "root";
        String dbPassword = "student";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish a database connection
            connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Insert order details into the database without orderid
            String sql = "INSERT INTO orders (uname, bName, aName,  totalPrice,DeliveryDate,paymenttype) VALUES (?, ?, ?, ?, ?,?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1, uname);
            statement.setString(2, bName);
            statement.setString(3, aName);
            statement.setDouble(4, Price);
            statement.setString(5, DeliveryDate);
            statement.setString(6, paymenttype);
            

            // Execute the insert
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
            	response.sendRedirect("ordersuccess.jsp");
            } else {
                response.getWriter().println("Failed to place the order.");
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
