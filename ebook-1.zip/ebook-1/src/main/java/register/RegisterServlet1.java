package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Database;
import profile.User;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

@WebServlet("/signup")
public class RegisterServlet1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Get the previous session
        HttpSession session = request.getSession();
        
        // Create a new user object
        User user = new User();
        
        // Update form3 input
        user.setEmail(request.getParameter("email"));
        user.setMobile(Long.parseLong(request.getParameter("mobile")));
        user.setfName(request.getParameter("fname"));
        user.setUname(request.getParameter("uname"));
        user.setPass(request.getParameter("pass"));
        
        session.setAttribute("user", user); 

        // Update into db
        Database db = new Database("user");
        try {
            // Check for existing username, email, or mobile number
            if (db.isUsernameExists(user.getUname())) {
                request.setAttribute("errorMessage", "Username already exists.");
                request.getRequestDispatcher("signup.jsp").forward(request, response);
                return;
            }
            if (db.isEmailExists(user.getEmail())) {
                request.setAttribute("errorMessage", "Email already exists.");
                request.getRequestDispatcher("signup.jsp").forward(request, response);
                return;
            }
            if (db.isMobileExists(user.getMobile())) {
                request.setAttribute("errorMessage", "Mobile number already exists.");
                request.getRequestDispatcher("signup.jsp").forward(request, response);
                return;
            }

            // If all checks pass, insert the user into the database
            db.insert(user);

            // Send confirmation email
            sendConfirmationEmail(user);
            response.sendRedirect("login.jsp");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred. Please try again.");
            request.getRequestDispatcher("signup.jsp").forward(request, response);
        }
    }

    private void sendConfirmationEmail(User user) {
        // Set up email properties
        String host = "smtp.gmail.com";
        String from = "devilsgalaxee@gmail.com";
        String password = "kwkx athi euyo indj";  // Replace with your actual email password

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", "587");

        // Create a session with an authenticator
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            // Create a new email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
            message.setSubject("Registration Confirmation");

            // Customize the email body with the user's first name and additional text
            String emailBody = "Hello " + user.getfName() + ",\n\n" +
                    "Thank you for registering with us! We’re excited to have you on board.\n\n" +
                    "Your account has been created successfully, and you can now log in to explore our services.\n\n" +
                    "If you have any questions or need further assistance, feel free to reach out to us.\n\n" +
                    "Best regards,\nThe Support Team";

            message.setText(emailBody);

            // Send the message
            Transport.send(message);

            System.out.println("Confirmation email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Failed to send confirmation email.");
        }
    }

}
