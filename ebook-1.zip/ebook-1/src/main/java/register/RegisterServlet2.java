package register;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import profile.Database;
import profile.Books;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

@WebServlet("/books")
@MultipartConfig(maxFileSize = 1024 * 1024 * 10) // 10MB max size
public class RegisterServlet2 extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Get the prev session
        HttpSession session = request.getSession();
        
        // Get the session attribute
        Books books = new Books();
        
        // Update form3 input 
        books.setbName(request.getParameter("bname"));
        books.setBid(request.getParameter("bid"));
        books.setaName(request.getParameter("aname"));
        books.setYear(request.getParameter("year"));
        
        // Parse count as an integer
        String countStr = request.getParameter("count");
        int count = (countStr != null && !countStr.isEmpty()) ? Integer.parseInt(countStr) : 0;
        books.setCount(count);
        books.setPrice(request.getParameter("price"));

        books.setDescr(request.getParameter("descr"));
        
        // Handle image data (uploaded as a file)
        Part imgPart = request.getPart("img");
        if (imgPart != null && imgPart.getSize() > 0) {
            InputStream imgInputStream = imgPart.getInputStream();
            byte[] imgBytes = imgInputStream.readAllBytes();
            books.setImg(imgBytes);
        }
        
        session.setAttribute("books", books); 

        // Update into db
        Database db = new Database("user");
        try {
            db.insert1(books);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Invalidate the session
        session.invalidate();
        
        // Respond
        response.sendRedirect("orders728");
    }
}
