package profile;

import java.util.Base64;

public class Books {
    private String bName;
    private String bid;
    private String aName;
    private int count;
    private String price;
    private String year;
    private String descr;
    private byte[] img;

    // Getters and Setters
    public String getbName() { return bName; }
    public void setbName(String bName) { this.bName = bName; }

    public String getBid() { return bid; }
    public void setBid(String bid) { this.bid = bid; }

    public String getaName() { return aName; }
    public void setaName(String aName) { this.aName = aName; }

    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }

    public String getYear() { return year; }
    public void setYear(String year) { this.year = year; }

    public String getDescr() { return descr; }
    public void setDescr(String descr) { this.descr = descr; }

    public byte[] getImg() { return img; }
    public void setImg(byte[] img) { this.img = img; }

    // Method to get Base64-encoded image string
    public String getImgBase64() {
        return Base64.getEncoder().encodeToString(this.img);
    }
}
