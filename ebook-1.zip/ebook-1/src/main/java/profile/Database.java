	package profile;
	
	import java.sql.*;
	import java.util.ArrayList;
	import java.util.List;
	
	public class Database {
	
	    String url, uname, pass, db;
	    Connection con;
	    String query;
	    Statement st;
	    PreparedStatement pt;
	
	    public Database(String db) {
	        super();
	        this.db = db;
	        this.url = "jdbc:mysql://localhost:3306/" + this.db;
	        this.uname = "root";
	        this.pass = "student";
	    }
	
	    public void connection() throws SQLException, ClassNotFoundException {
	        // Load the MySQL JDBC driver
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        
	        // Create connection
	        con = DriverManager.getConnection(url, uname, pass);
	    }
	
	    public User read(String uname) throws SQLException, ClassNotFoundException {
	
	        // Load the driver and create connection
	        this.connection();
	
	        // Write query
	        query = "select * from customer where uname='" + uname + "'";
	
	        // Create statement
	        st = con.createStatement();
	
	        // Execute statement
	        ResultSet result = st.executeQuery(query);
	        User user = new User();
	
	        // Process the result (select)
	        while (result.next()) {
	            user.setEmail(result.getString(1));
	            user.setMobile(result.getLong(2));
	            user.setfName(result.getString(3));
	            user.setUname(result.getString(4));
	            user.setPass(result.getString(5));
	        }
	
	        // Close the connection
	        con.close();
	        return user;
	    }
	   
	    public Admin read1(String uname) throws SQLException, ClassNotFoundException {
	        this.connection();
	
	        // Write query
	        query = "select * from admin where uname='" + uname + "'";
	
	        // Create statement
	        st = con.createStatement();
	
	        // Execute statement
	        ResultSet result = st.executeQuery(query);
	        Admin admin = new Admin();
	
	        // Process the result (select)
	        while (result.next()) {
	            admin.setUname(result.getString(1));
	            admin.setPass(result.getString(2));
	        }
	
	        // Close the connection
	        con.close();
	        return admin;
	    }
	
	
	    public int insert(User user) throws SQLException, ClassNotFoundException {
	        // Load the driver and create connection
	        this.connection();
	
	        // Write query
	        this.query = "insert into customer values( ?, ?, ?, ?, ?)";
	
	        // Create prepared statement
	        pt = con.prepareStatement(query);
	        pt.setString(1, user.getEmail());
	        pt.setLong(2, user.getMobile());
	        pt.setString(3, user.getfName());
	        pt.setString(4, user.getUname());
	        pt.setString(5, user.getPass());
	
	        // Execute prepared statement
	        int row = pt.executeUpdate();
	
	        // Close connection
	        con.close();
	
	        return row;
	    }
	
	    public int insert1(Books books) throws SQLException, ClassNotFoundException {
	        // Load the driver and create connection
	        this.connection();
	
	        // Write query
	        this.query = "insert into books values( ?, ?, ?, ?, ?, ?, ?,?)";
	
	        // Create prepared statement
	        pt = con.prepareStatement(query);
	        pt.setString(1, books.getbName());
	        pt.setString(2, books.getBid());
	        pt.setString(3, books.getaName());
	        pt.setInt(4, books.getCount());
	        pt.setString(5, books.getPrice());
	
	        pt.setString(6, books.getYear());
	        pt.setString(7, books.getDescr()); 
	        pt.setBytes(8, books.getImg());
	
	        // Execute prepared statement
	        int row = pt.executeUpdate();
	
	        // Close connection
	        con.close();
	
	        return row;
	    }
	    public int insert2(Address address) throws SQLException, ClassNotFoundException {
	        // Load the driver and create connection
	        this.connection();
	
	        // Write query for inserting into address table
	        this.query = "insert into address values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	        // Create prepared statement
	        pt = con.prepareStatement(query);
	        pt.setString(1, address.getUname());
	        pt.setString(2, address.getfName());
	        pt.setLong(3, address.getMobile());
	        pt.setInt(4, address.getPincode());
	        pt.setString(5, address.getLandmark());
	        pt.setString(6, address.getArea());
	        pt.setString(7, address.getCity());
	        pt.setString(8, address.getMandal());
	        pt.setString(9, address.getDistrict());
	        pt.setString(10, address.getState());
	
	        // Execute prepared statement
	        int row = pt.executeUpdate();
	
	        // Close connection
	        con.close();
	
	        return row;
	    }
	    public List<Books> getAllBooks() throws SQLException, ClassNotFoundException {
	        List<Books> booksList = new ArrayList<>();
	        this.connection();
	
	        String query = "SELECT * FROM books";
	        Statement st = con.createStatement();
	        ResultSet result = st.executeQuery(query);
	
	        while (result.next()) {
	            Books book = new Books();
	            book.setbName(result.getString("bName"));
	            book.setBid(result.getString("bid"));
	            book.setaName(result.getString("aName"));
	            book.setCount(result.getInt("count"));
	            book.setPrice(result.getString("price"));
	            book.setYear(result.getString("year"));
	            book.setDescr(result.getString("descr"));
	            book.setImg(result.getBytes("img"));  // Store the image as a byte array
	            booksList.add(book);
	        }
	
	        con.close();
	        return booksList;
	    }
	    public Books getBookById(String bookId) throws SQLException, ClassNotFoundException {
	        this.connection();
	        String query = "SELECT * FROM books WHERE bid=?";
	        PreparedStatement pt = con.prepareStatement(query);
	        pt.setString(1, bookId);
	        ResultSet result = pt.executeQuery();
	        Books book = null;
	        if (result.next()) {
	            book = new Books();
	            book.setbName(result.getString("bName"));
	            book.setBid(result.getString("bid"));
	            book.setaName(result.getString("aName"));
	            book.setCount(result.getInt("count"));
	            book.setPrice(result.getString("price"));
	            book.setYear(result.getString("year"));
	            book.setDescr(result.getString("descr"));
	            book.setImg(result.getBytes("img")); // Store the image as a byte array
	        }
	        con.close();
	        return book;
	    }
	
	    public int delete(String uName) throws SQLException, ClassNotFoundException {
	        // Load the driver and create connection
	        this.connection();
	
	        // Write query
	        this.query = "delete from customer where uname=?";
	
	        // Create prepared statement
	        pt = con.prepareStatement(query);
	        pt.setString(1, uName);
	
	        // Execute statement
	        int row = pt.executeUpdate();
	
	        // Close connection
	        con.close();
	        return row;
	    }
	
	    public int validate(String uname, String password, String userType) throws SQLException, ClassNotFoundException {
	        this.connection();
	
	        if ("customer".equals(userType)) {
	            query = "SELECT pass FROM customer WHERE uname=?";
	        } else if ("admin".equals(userType)) {
	            query = "SELECT pass FROM admin WHERE uname=?";
	        } else {
	            con.close();
	            return 1; // Invalid user type
	        }
	
	        pt = con.prepareStatement(query);
	        pt.setString(1, uname);
	        ResultSet result = pt.executeQuery();
	
	        if (!result.next()) {
	            con.close();
	            return 1; // Username not found
	        }
	        
	        if (result.getString(1).equals(password)) {
	            con.close();
	            return 2; // Valid credentials
	        } else {
	            con.close();
	            return 3; // Invalid password
	        }
	    }
	
	    public boolean isUsernameExists(String uname) throws SQLException, ClassNotFoundException {
	        this.connection();
	        query = "SELECT uname FROM customer WHERE uname = ?";
	        pt = con.prepareStatement(query);
	        pt.setString(1, uname);
	        ResultSet result = pt.executeQuery();
	        boolean exists = result.next();
	        con.close();
	        return exists;
	    }
	
	    public boolean isEmailExists(String email) throws SQLException, ClassNotFoundException {
	        this.connection();
	        query = "SELECT email FROM customer WHERE email = ?";
	        pt = con.prepareStatement(query);
	        pt.setString(1, email);
	        ResultSet result = pt.executeQuery();
	        boolean exists = result.next();
	        con.close();
	        return exists;
	    }
	
	    public boolean isMobileExists(long mobile) throws SQLException, ClassNotFoundException {
	        this.connection();
	        query = "SELECT mobile FROM customer WHERE mobile = ?";
	        pt = con.prepareStatement(query);
	        pt.setLong(1, mobile);
	        ResultSet result = pt.executeQuery();
	        boolean exists = result.next();
	        con.close();
	        return exists;
	    }
	    public Address getAddressByUsername(String uname) throws SQLException, ClassNotFoundException {
	        this.connection(); // Ensure `connection` method initializes `con`
	        String query = "SELECT * FROM address WHERE uname=?";
	        PreparedStatement pt = con.prepareStatement(query);
	        pt.setString(1, uname);

	        ResultSet result = pt.executeQuery();
	        Address address = null;

	        if (result.next()) {
	            address = new Address();
	            address.setUname(result.getString("uname"));
	            address.setfName(result.getString("fName"));
	            address.setMobile(result.getLong("mobile"));
	            address.setPincode(result.getInt("pincode"));
	            address.setLandmark(result.getString("landmark"));
	            address.setArea(result.getString("area"));
	            address.setCity(result.getString("city"));
	            address.setMandal(result.getString("mandal"));
	            address.setDistrict(result.getString("district"));
	            address.setState(result.getString("state"));

	            // Debugging: Print the retrieved address
	            System.out.println("Fetched Address: " + address.getfName());
	        } else {
	            System.out.println("No address found for username: " + uname);
	        }

	        con.close();
	        return address;
	    }

	    
	    public int insert3(Productfinal pfinal) throws SQLException, ClassNotFoundException {
	        // Load the driver and create connection
	        this.connection();
	
	        // Write query for inserting into address table
	        this.query = "insert into orders values( ?, ?, ?, ?, ?)";
	
	        // Create prepared statement
	        pt = con.prepareStatement(query);
	        pt.setString(1, pfinal.getaName());
	        pt.setString(2, pfinal.getbName());
	        pt.setString(3, pfinal.getPrice());
	       
	      
	        pt.setString(4, pfinal.getUname());
	        pt.setString(5, pfinal.getDeliveryDate());
	        System.out.println("bName value for SQL: " + pfinal.getbName());
	
	      
	       
	
	        // Execute prepared statement
	        int row = pt.executeUpdate();
	
	        // Close connection
	        con.close();
	
	        return row;
	    }
	    
	   
	    
	    public List<Productfinal> getOrdersByUsername(String uname) throws SQLException {
	        List<Productfinal> orders = new ArrayList<>();
	        String query = "SELECT * FROM orders WHERE uname = ?"; // Fetch orders for a specific username

	        // Establish connection
	        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/user", "root", "student");
	             PreparedStatement stmt = connection.prepareStatement(query)) {
	            
	            stmt.setString(1, uname);  // Set username in the query
	            try (ResultSet rs = stmt.executeQuery()) {
	                while (rs.next()) {
	                    Productfinal order = new Productfinal();
	                    order.setbName(rs.getString("bname"));
	                    order.setaName(rs.getString("aname"));
	                    order.setUname(rs.getString("uname"));
	                    order.setPaymenttype(rs.getString("paymenttype"));
	                    order.setPrice(rs.getString("totalprice"));
	                    order.setDeliveryDate(rs.getString("DeliveryDate"));
	                    order.setStatus(rs.getString("status"));
	                    orders.add(order);
	                }
	            }
	        }
	        return orders;
	    }
	    
	    public List<Productfinal> getAllOrders() throws SQLException {
	        List<Productfinal> orders = new ArrayList<>();
	        String query = "SELECT * FROM orders"; // Fetch all orders

	        // Establish connection
	        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/user", "root", "student");
	             PreparedStatement stmt = connection.prepareStatement(query);
	             ResultSet rs = stmt.executeQuery()) {

	            while (rs.next()) {
	                Productfinal order = new Productfinal();
	                order.setbName(rs.getString("bname"));
	                order.setaName(rs.getString("aname"));
	                order.setUname(rs.getString("uname"));
	                order.setPaymenttype(rs.getString("paymenttype"));
	                order.setPrice(rs.getString("totalprice"));
	                order.setDeliveryDate(rs.getString("DeliveryDate"));
	                order.setStatus(rs.getString("status"));
	                
	                orders.add(order);
	            }
	        }
	        return orders;
	    }




	   
	}
