package login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import profile.Productfinal;
import profile.Database;

import java.io.IOException;
import java.util.List;

@WebServlet("/orders728")
public class AdmDashServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Database db = new Database("user");

        try {
            // Fetch all orders from the database
            List<Productfinal> orders = db.getAllOrders();
            System.out.println("Number of orders retrieved: " + orders.size());

            // Set the orders attribute in the request
            request.setAttribute("orders", orders);

            // Forward the request to the JSP page
            request.getRequestDispatcher("admin.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to fetch orders");
        }
    }
}
