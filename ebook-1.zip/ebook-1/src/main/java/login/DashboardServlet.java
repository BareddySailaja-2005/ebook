package login;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Books;
import profile.Database;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Database db = new Database("user");
        HttpSession session = request.getSession(false);

        String username = (String) session.getAttribute("username"); // Retrieve the username from the session

        try {
            // Retrieve list of books from the database
            List<Books> booksList = db.getAllBooks();
            System.out.println("Number of books retrieved: " + booksList.size());

            // Set the booksList and username attributes in the request
            request.setAttribute("booksList", booksList);
            request.setAttribute("username", username);

            // Forward the request to the JSP page for displaying the books
            request.getRequestDispatcher("home.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
