package login;

import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Address;
import profile.Database;

@WebServlet("/address1") // Ensure this mapping matches your JSP request
public class AddressServlet1 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve username from session
        HttpSession session = request.getSession();
        String uname = (String) session.getAttribute("username");

        // Debugging: Log session username
        System.out.println("Username from session: " + uname);

        if (uname == null || uname.isEmpty()) {
            // Redirect to login page if username is not in session
            response.sendRedirect("login.jsp");
            return;
        }

        // Create a Database object
        Database db = new Database("user");

        try {
            // Fetch address details using the username
            Address address = db.getAddressByUsername(uname);

            if (address != null) {
                // Pass the address object to the JSP
                request.setAttribute("address", address);
                RequestDispatcher rd = request.getRequestDispatcher("addressd.jsp");
                rd.forward(request, response);
            } else {
                // Address not found
                request.setAttribute("error", "No address found for user: " + uname);
                RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
                rd.forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error fetching address: " + e.getMessage());
            RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
            rd.forward(request, response);
        }
    }
}
