package login;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import profile.Books;
import profile.Database;
import profile.Address;

@WebServlet("/productServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Database db;

    @Override
    public void init() throws ServletException {
        db = new Database("user"); // replace with your actual database name
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String bookId = request.getParameter("bookId");
        String uname = request.getParameter("uname"); // Assuming you have the username from the session or request

        try {
            // Fetch book details
            Books book = db.getBookById(bookId);
            request.setAttribute("book", book);

            // Fetch address details
            Address address = db.getAddressByUsername(uname);
            if (address != null) {
                System.out.println("Address fetched: " + address.getfName());
            } 
            request.setAttribute("address", address);

            // Forward to JSP
            RequestDispatcher dispatcher = request.getRequestDispatcher("product.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }}
