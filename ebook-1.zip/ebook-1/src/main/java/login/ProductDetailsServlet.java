package login;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Database;

import java.io.IOException;
import java.sql.SQLException;
@WebServlet("/productDetails")
public class ProductDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the session
        HttpSession session = request.getSession();
        
        // Retrieve the username from session
        String username = (String) session.getAttribute("username");
        
        // Fetch other details from the request
        String bookName = request.getParameter("bookName");
        String authorName = request.getParameter("authorName");
        String price = request.getParameter("price");
        String bookId=request.getParameter("bookId");
        
        // Set these details in the request scope
        request.setAttribute("username", username);
        request.setAttribute("bookName", bookName);
        request.setAttribute("authorName", authorName);
        request.setAttribute("price", price);
        request.setAttribute("bookId", bookId);
        
        // Forward to productfinal.jsp
        request.getRequestDispatcher("productfinal.jsp").forward(request, response);
    }
}
