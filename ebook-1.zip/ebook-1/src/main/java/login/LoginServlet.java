package login;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import profile.Books;
import profile.Database;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String uname = request.getParameter("uname");

        String pass = request.getParameter("pass");
        String userType = request.getParameter("userType");

        Database db = new Database("user");

        try {
            int result = db.validate(uname, pass, userType);

            switch (result) {
                case 1: 
                    session.setAttribute("error", "Username is wrong");
                    response.sendRedirect("login.jsp");
                    break;

                case 2: 
                    session.setAttribute("username", uname); 
                    session.setAttribute("userType", userType); 
                    System.out.println("Username from session: " + uname);


                    if ("admin".equals(userType)) {
                        response.sendRedirect("orders728"); // Redirect to admin dashboard
                    } else {
                        List<Books> booksList = db.getAllBooks();
                        System.out.println("Number of books retrieved: " + booksList.size());

                        session.setAttribute("booksList", booksList); // Set booksList in the session
                        response.sendRedirect("home.jsp"); // Redirect to home page
                    }
                    break;

                case 3:
                    session.setAttribute("error", "Password is wrong");
                    response.sendRedirect("login.jsp");
                    break;

                default:
                    session.setAttribute("error", "An unexpected error occurred");
                    response.sendRedirect("login.jsp");
                    break;
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            session.setAttribute("error", "An error occurred while processing your request");
            response.sendRedirect("login.jsp");
        }
    }
}
